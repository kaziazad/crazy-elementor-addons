<?php

namespace CrazyAddons;

// Exit if accessed directly (security check)
if (!defined('ABSPATH')) {
    exit;
}

class Plugin {
    // Holds the singleton instance
    private static $instance = null;

    /**
     * Returns the single instance of the class
     * Creates the instance if it doesn't exist yet
     */
    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self(); // Call the private constructor
        }
        return self::$instance;
    }

    /**
     * Private constructor to enforce singleton pattern
     */
    private function __construct() {
        $this->define_constants(); // Define required constants
        $this->includes();         // Include required PHP files
        $this->init_hooks();       // Register WordPress and Elementor hooks
    }

    /**
     * Define path and URL constants used throughout the plugin
     */
    private function define_constants() {
        define('CRAZY_ADDONS_PATH', plugin_dir_path(__DIR__));
        define('CRAZY_ADDONS_URL', plugin_dir_url(__DIR__));
    }

    /**
     * Include necessary plugin files
     */
    private function includes() {
        require_once CRAZY_ADDONS_PATH . 'includes/widget_loader.php';
        require_once CRAZY_ADDONS_PATH . 'includes/register-category.php';
    }

    /**
     * Register hooks for Elementor and WordPress
     */
    private function init_hooks() {
        // Register widgets when Elementor initializes
        add_action('elementor/widgets/register', [__NAMESPACE__ . '\widget_loader', 'register_widgets']);

        // Enqueue frontend scripts and styles
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);

        // Register custom Elementor widget category after Elementor is loaded
        if (did_action('elementor/loaded')) {
            new \CrazyAddons\Widget_Category_Registrar();
        }
    }

    /**
     * Enqueue external and local assets for frontend use
     */
    public function enqueue_assets() {
        // Swiper.js CSS from CDN
        wp_enqueue_style('crazy-swiper', 'https://unpkg.com/swiper/swiper-bundle.min.css');

        // Swiper.js script from CDN
        wp_enqueue_script('crazy-swiper', 'https://unpkg.com/swiper/swiper-bundle.min.js', [], null, true);
    
        // Local CSS files for Swiper styling
        wp_enqueue_style('crazy-swiper-style', CRAZY_ADDONS_URL . 'assets/css/swiper-style.css');
        wp_enqueue_style('crazy-swiper-style-hr', CRAZY_ADDONS_URL . 'assets/css/swiper-style-hr.css');
    }
}
