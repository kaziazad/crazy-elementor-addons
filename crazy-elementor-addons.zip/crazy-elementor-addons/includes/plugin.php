<?php

namespace CrazyAddons;

if (!defined('ABSPATH')) {
    exit;
}

class Plugin {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->define_constants();
        $this->includes();
        $this->init_hooks();
    }

    private function define_constants() {
        define('CRAZY_ADDONS_PATH', plugin_dir_path(__DIR__));
        define('CRAZY_ADDONS_URL', plugin_dir_url(__DIR__));
    }

    private function includes() {
        require_once CRAZY_ADDONS_PATH . 'includes/widget_loader.php';
        require_once CRAZY_ADDONS_PATH . 'includes/register-category.php';
    }

    private function init_hooks() {
        add_action('elementor/widgets/register', [__NAMESPACE__ . '\widget_loader', 'register_widgets']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
         if ( did_action( 'elementor/loaded' ) ) {
        new \CrazyAddons\Widget_Category_Registrar();
    }
    }

    public function enqueue_assets() {
        wp_enqueue_style('crazy-swiper', 'https://unpkg.com/swiper/swiper-bundle.min.css');
        wp_enqueue_script('crazy-swiper', 'https://unpkg.com/swiper/swiper-bundle.min.js', [], null, true);
        // wp_enqueue_script('crazy-swiper-init', CRAZY_ADDONS_URL . 'assets/js/swiper-init.js', ['crazy-swiper'], null, true);
        wp_enqueue_style('crazy-swiper-style', CRAZY_ADDONS_URL . 'assets/css/swiper-style.css');
        wp_enqueue_style('crazy-swiper-style-hr', CRAZY_ADDONS_URL . 'assets/css/swiper-style-hr.css');
    }
}
