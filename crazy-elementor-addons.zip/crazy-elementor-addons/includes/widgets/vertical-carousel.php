<?php

namespace CrazyAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Utils;

if (!defined('ABSPATH')) {
    exit;
}

class Vertical_Carousel extends Widget_Base {

    public function get_name() {
        return 'crazy_vertical_carousel';
    }

    public function get_title() {
        return __('Vertical Image Carousel', 'crazy_addons');
    }

    public function get_icon() {
        return 'eicon-slider-push';
    }

    public function get_categories() {
        return ['crazi-elementor-category'];
    }

    protected function register_controls() {
        $this->start_controls_section('carousel_section', [
            'label' => __('Carousel Images', 'crazy_addons'),
        ]);

        $repeater = new Repeater();

        $repeater->add_control('carousel_image', [
            'label' => __('Image', 'crazy_addons'),
            'type' => Controls_Manager::MEDIA,
            'default' => ['url' => Utils::get_placeholder_image_src()],
        ]);

        $this->add_control('carousel_items', [
            'label' => __('Carousel Items', 'crazy_addons'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'title_field' => 'Image',
        ]);

        $this->end_controls_section();

        $this->register_style_controls();
    }


    protected function register_style_controls() {
        $this->start_controls_section(
            'section_style_images',
            [
                'label' => esc_html__('Image Style', 'crazy_addons'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_responsive_control(
            'carousel_gap',
            [
                'label' => esc_html__('Carousel Gap', 'crazy_addons'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crazy-carousel-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'image_padding',
            [
                'label' => esc_html__('Image Padding', 'crazy_addons'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .carousel-slide img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->add_responsive_control(
    'image_margin',
    [
        'label' => esc_html__('Image Margin', 'crazy_addons'),
        'type' => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%', 'em'],
        'selectors' => [
            '{{WRAPPER}} .carousel-slide' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
        ],
    ]
);
    
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'selector' => '{{WRAPPER}} .carousel-slide img',
            ]
        );
    
        $this->add_responsive_control(
            'image_border_radius',
            [
                'label' => esc_html__('Image Border Radius', 'crazy_addons'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .carousel-slide img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->end_controls_section();
    }
    

    protected function render() {
        $settings = $this->get_settings_for_display();
        if (empty($settings['carousel_items'])) return;
    
        echo '<div class="crazy-carousel-wrapper">';
    
        for ($col = 1; $col <= 3; $col++) {
            $direction_class = ($col === 2) ? 'scroll-up' : 'scroll-down';
            echo '<div class="crazy-carousel-column ' . esc_attr($direction_class) . '">';
            echo '<div class="carousel-track">';
            
            // Duplicate the slides to make loop smooth
            for ($i = 0; $i < 2; $i++) {
                foreach ($settings['carousel_items'] as $item) {
                    echo '<div class="carousel-slide">';
                    echo '<img src="' . esc_url($item['carousel_image']['url']) . '" alt="" />';
                    echo '</div>';
                }
            }
    
            echo '</div></div>';
        }
    
        echo '</div>';
    }
    
}
