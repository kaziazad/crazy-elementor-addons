<?php

namespace CrazyAddons\Widgets;

// Import necessary Elementor classes
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Utils;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Vertical_Carousel Widget Class
 * 
 * Creates a vertical image carousel with multiple columns using Elementor.
 */
class Vertical_Carousel extends Widget_Base {

    /**
     * Get widget slug (unique identifier)
     */
    public function get_name() {
        return 'crazy_vertical_carousel';
    }

    /**
     * Get widget title (displayed in Elementor panel)
     */
    public function get_title() {
        return __('Vertical Image Carousel', 'crazy_addons');
    }

    /**
     * Get widget icon (for Elementor panel)
     */
    public function get_icon() {
        return 'eicon-slider-push';
    }

    /**
     * Get widget category (registered earlier)
     */
    public function get_categories() {
        return ['crazi-elementor-category'];
    }

    /**
     * Register content controls (carousel images)
     */
    protected function register_controls() {
        $this->start_controls_section('carousel_section', [
            'label' => __('Carousel Images', 'crazy_addons'),
        ]);

        // Setup repeater to allow multiple image uploads
        $repeater = new Repeater();

        $repeater->add_control('carousel_image', [
            'label' => __('Image', 'crazy_addons'),
            'type' => Controls_Manager::MEDIA,
            'default' => ['url' => Utils::get_placeholder_image_src()],
        ]);

        // Add repeater field to the widget control panel
        $this->add_control('carousel_items', [
            'label' => __('Carousel Items', 'crazy_addons'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'title_field' => 'Image',
        ]);

        $this->end_controls_section();

        // Register style controls for design customization
        $this->register_style_controls();
    }

    /**
     * Register style controls (padding, margin, border, etc.)
     */
    protected function register_style_controls() {
        $this->start_controls_section(
            'section_style_images',
            [
                'label' => esc_html__('Image Style', 'crazy_addons'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // Gap between carousel columns
        $this->add_responsive_control(
            'carousel_gap',
            [
                'label' => esc_html__('Carousel Gap', 'crazy_addons'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crazy-carousel-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Padding for each image
        $this->add_responsive_control(
            'image_padding',
            [
                'label' => esc_html__('Image Padding', 'crazy_addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .carousel-slide img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Margin around each image container
        $this->add_responsive_control(
            'image_margin',
            [
                'label' => esc_html__('Image Margin', 'crazy_addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .carousel-slide' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
            ]
        );

        // Border settings for the image
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'selector' => '{{WRAPPER}} .carousel-slide img',
            ]
        );

        // Border radius for rounded corners
        $this->add_responsive_control(
            'image_border_radius',
            [
                'label' => esc_html__('Image Border Radius', 'crazy_addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .carousel-slide img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render the widget HTML on the frontend
     */
    protected function render() {
        // Get widget settings
        $settings = $this->get_settings_for_display();

        // If no images provided, return nothing
        if (empty($settings['carousel_items'])) return;

        // Wrapper container for carousel
        echo '<div class="crazy-carousel-wrapper">';

        // Create 3 vertical columns with different scroll directions
        for ($col = 1; $col <= 3; $col++) {
            // Middle column scrolls up, others scroll down
            $direction_class = ($col === 2) ? 'scroll-up' : 'scroll-down';
            echo '<div class="crazy-carousel-column ' . esc_attr($direction_class) . '">';
            echo '<div class="carousel-track">';

            // Duplicate the slides twice for smooth infinite looping
            for ($i = 0; $i < 2; $i++) {
                foreach ($settings['carousel_items'] as $item) {
                    echo '<div class="carousel-slide">';
                    echo '<img src="' . esc_url($item['carousel_image']['url']) . '" alt="" />';
                    echo '</div>';
                }
            }

            echo '</div></div>'; // Close track and column
        }

        echo '</div>'; // Close wrapper
    }

}
