<?php

// Define the namespace for the custom Elementor widget
namespace CrazyAddons\Widgets;

// Import necessary Elementor classes
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Utils;

// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

// Define the custom widget class
class Horizontal_Carousel extends Widget_Base {

    // Return the widget's unique name (used internally)
    public function get_name() {
        return 'crazy_horizontal_carousel';
    }

    // Return the widget title (visible in Elementor editor)
    public function get_title() {
        return __('Horizontal Image Carousel', 'crazy_addons');
    }

    // Return the widget icon (displayed in Elementor editor panel)
    public function get_icon() {
        return 'eicon-slider-push';
    }

    // Assign the widget to a custom category
    public function get_categories() {
        return ['crazi-elementor-category'];
    }

    // Register controls visible in Elementor's Content tab
    protected function register_controls() {
        // Start a section for the image carousel
        $this->start_controls_section('carousel_section', [
            'label' => __('Carousel Images', 'crazy_addons'),
        ]);

        // Create a repeater field for multiple image inputs
        $repeater = new Repeater();

        // Add image control inside repeater
        $repeater->add_control('carousel_image', [
            'label' => __('Image', 'crazy_addons'),
            'type' => Controls_Manager::MEDIA,
            'default' => ['url' => Utils::get_placeholder_image_src()],
        ]);

        // Add repeater control to the widget
        $this->add_control('carousel_items', [
            'label' => __('Carousel Items', 'crazy_addons'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'title_field' => 'Image',
        ]);

        // End the content section
        $this->end_controls_section();

        // Register style controls
        $this->register_style_controls();
    }

    // Register controls for the Style tab in Elementor
    protected function register_style_controls() {
        // Start the image style section
        $this->start_controls_section(
            'section_style_images',
            [
                'label' => esc_html__('Image Style', 'crazy_addons'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Add control for spacing between carousel items
        $this->add_responsive_control(
            'carousel_gap',
            [
                'label' => esc_html__('Carousel Gap', 'crazy_addons'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .crazy-carousel-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Add control for padding inside images
        $this->add_responsive_control(
            'image_padding',
            [
                'label' => esc_html__('Image Padding', 'crazy_addons'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .carousel-slide img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Add control for margin around image slide containers
        $this->add_responsive_control(
            'image_margin',
            [
                'label' => esc_html__('Image Margin', 'crazy_addons'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .carousel-slide' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
            ]
        );

        // Add border control to images
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'selector' => '{{WRAPPER}} .carousel-slide img',
            ]
        );

        // Add control for border radius of images
        $this->add_responsive_control(
            'image_border_radius',
            [
                'label' => esc_html__('Image Border Radius', 'crazy_addons'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .carousel-slide img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // End the style section
        $this->end_controls_section();
    }

    // Output the widget HTML on the frontend
    protected function render() {
        // Get the settings values
        $settings = $this->get_settings_for_display();

        // Exit if no carousel items are provided
        if (empty($settings['carousel_items'])) return;

        // Start the main carousel wrapper
        echo '<div class="crazy-carousel-wrapper-hr">';

        // Loop through 3 columns to create multiple direction animations
        for ($col = 1; $col <= 3; $col++) {
            // Set direction class: middle column scrolls right, others scroll left
            $direction_class = ($col === 2) ? 'scroll-right-hr' : 'scroll-left-hr';

            // Start one carousel track column
            echo '<div class="crazy-carousel-hr ' . esc_attr($direction_class) . '">';
            echo '<div class="carousel-track-hr">';

            // Duplicate items twice to create infinite scroll effect
            for ($i = 0; $i < 2; $i++) {
                foreach ($settings['carousel_items'] as $item) {
                    echo '<div class="carousel-slide-hr">';
                    echo '<img src="' . esc_url($item['carousel_image']['url']) . '" alt="" />';
                    echo '</div>';
                }
            }

            // Close carousel-track and column
            echo '</div></div>';
        }

        // Close the main wrapper
        echo '</div>';
    }

}
