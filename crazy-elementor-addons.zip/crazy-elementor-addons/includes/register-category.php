<?php

namespace CrazyAddons;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_Category_Registrar {

    public function __construct() {
        add_action( 'elementor/elements/categories_registered', [ $this, 'register_custom_widget_category' ] );
    }

    public function register_custom_widget_category( $elements_manager ) {
        $elements_manager->add_category(
            'crazi-elementor-category',
            [
                'title' => __( 'Crazi Elementor', 'crazy_addons' ),
                'icon'  => 'fa fa-plug', // Optional icon
            ]
        );
    }
}
