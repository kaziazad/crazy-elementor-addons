<?php

namespace CrazyAddons;

// Exit if accessed directly to prevent unauthorized access
if (!defined('ABSPATH')) exit;

/**
 * Class Widget_Category_Registrar
 * 
 * Responsible for registering a custom widget category in Elementor.
 */
class Widget_Category_Registrar {

    /**
     * Constructor
     * Hooks the custom category registration method into Elementor.
     */
    public function __construct() {
        // Register the custom widget category when Elementor categories are initialized
        add_action('elementor/elements/categories_registered', [ $this, 'register_custom_widget_category' ]);
    }

    /**
     * Registers a custom widget category in Elementor's widget panel.
     *
     * @param \Elementor\Elements_Manager $elements_manager Elementor's elements manager.
     */
    public function register_custom_widget_category($elements_manager) {
        $elements_manager->add_category(
            'crazi-elementor-category', // Unique category slug
            [
                'title' => __( 'Crazi Elementor', 'crazy_addons' ), // Display title (translatable)
                'icon'  => 'fa fa-plug', // Optional icon for the category (Font Awesome class)
            ]
        );
    }
}
