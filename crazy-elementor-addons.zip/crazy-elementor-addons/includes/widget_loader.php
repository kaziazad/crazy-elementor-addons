<?php

namespace CrazyAddons;

use Elementor\Widgets_Manager;

if (!defined('ABSPATH')) {
    exit;
}

class Widget_Loader {
    public static function register_widgets(Widgets_Manager $widgets_manager) {
        require_once CRAZY_ADDONS_PATH . 'includes/widgets/vertical-carousel.php';
        $widgets_manager->register(new Widgets\Vertical_Carousel());
        require_once CRAZY_ADDONS_PATH . 'includes/widgets/horizontal-carousel.php';
        $widgets_manager->register(new Widgets\Horizontal_Carousel());
    }
}
