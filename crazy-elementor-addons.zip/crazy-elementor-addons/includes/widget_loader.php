<?php

namespace CrazyAddons;

use Elementor\Widgets_Manager;

// Exit if accessed directly (security check)
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Widget_Loader
 * 
 * Responsible for registering custom Elementor widgets.
 */
class Widget_Loader {

    /**
     * Registers custom widgets with Elementor's widget manager.
     *
     * @param Widgets_Manager $widgets_manager Elementor's widget manager instance.
     */
    public static function register_widgets(Widgets_Manager $widgets_manager) {
        // Include the Vertical Carousel widget file
        require_once CRAZY_ADDONS_PATH . 'includes/widgets/vertical-carousel.php';

        // Register the Vertical Carousel widget with Elementor
        $widgets_manager->register(new Widgets\Vertical_Carousel());

        // Include the Horizontal Carousel widget file
        require_once CRAZY_ADDONS_PATH . 'includes/widgets/horizontal-carousel.php';

        // Register the Horizontal Carousel widget with Elementor
        $widgets_manager->register(new Widgets\Horizontal_Carousel());
    }
}
