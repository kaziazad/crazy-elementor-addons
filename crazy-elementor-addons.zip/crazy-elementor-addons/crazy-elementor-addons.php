<?php
/**
 * Plugin Name:       Crazy Elementor Addons
 * Plugin URI:        https://kazimahmud.com/
 * Description:       Some Special widget for Elementor.
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Kazi Mahmud Al Azad
 * Author URI:        https://kazimahmud.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       crazy_addons
 * Domain Path:       /languages
 */


 if (!defined('ABSPATH')) exit;

 require_once plugin_dir_path(__FILE__) . 'includes/plugin.php';
 
 add_action('plugins_loaded', function () {
     \CrazyAddons\Plugin::instance();
 });

